
The documentation is stored in POD format in the smsfinder.pl script.

Please note the changes to the SMS format between v0.1 and v0.2

